from setuptools import setup

project_urls = {
  'Project Homepage': 'https://github.com/jadliaissam/django-gdpstorage'
}

setup(install_requires=['PyDrive2'], project_urls = project_urls)
